from random import choices
from django.db import models
from django.conf import settings

# Create your models here.
class Choice(models.Model):
    title = models.CharField(max_length=30)
    Issue_a = models.CharField(max_length=30)
    Issue_b = models.CharField(max_length=30)
    

RedORBlue = (
    ('RED', 'red'),
    ('BLUE', 'blue'),
)
class Comment(models.Model):
    choice = models.ForeignKey(Choice, on_delete=models.CASCADE)
    content = models.CharField(max_length=30)
    pick = models.CharField(max_length=30, choices = RedORBlue)
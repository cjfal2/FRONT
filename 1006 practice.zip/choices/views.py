from django.shortcuts import render, redirect

# Create your views here.
def index(request):
    return render(request, "choices/index.html")

def create(request):

    return render(request, "choices/create.html")
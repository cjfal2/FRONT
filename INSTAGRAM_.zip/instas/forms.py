from cProfile import label
from django import forms
from .models import Insta, Comment

class InstaForm(forms.ModelForm):

        class Meta:
            model = Insta
            fields = ('content', 'image')
            labels = {
                'content':'Content',
                'image':'Image',
            }
            widgets = {
                'content': forms.Textarea(attrs={
                    'class':'form-control',
                    'placeholder':'내용을 입력하세요.',
                    }),
                'image': forms.FileInput(attrs={
                    'class':'form-control',
                    'placeholder':'image',
                    }),
            }

class CommentForm(forms.ModelForm):

    class Meta:
        model = Comment
        fields = ('content',)
        labels = {
            'content':''
        }
        widgets = {
            'content': forms.TextInput(attrs={
                'class':'form-control',
                'placeholder':'댓글 달기...',
                }),
        }

from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods, require_POST, require_safe
from django.contrib.auth.decorators import login_required
from .models import Insta, Comment
from .forms import InstaForm, CommentForm
import random

@require_safe
def index(request):
    instas = Insta.objects.all()
    comment_form = CommentForm()
    context = {
        "instas":instas,
        "comment_form":comment_form,
    }
    return render(request, "instas/index.html", context)

@login_required
@require_http_methods(['GET', 'POST'])
def create(request):
    if request.method == 'POST':
        form = InstaForm(request.POST, request.FILES)
        if form.is_valid():
            insta = form.save(commit=False)
            insta.user = request.user
            insta.save()
            return redirect('instas:index')
    else:
        form = InstaForm()
    context = {
        'form': form,
    }
    return render(request, 'instas/create.html', context)


@require_safe
def detail(request, pk):
    insta = Insta.objects.get(pk=pk)
    comment_form = CommentForm()
    comments = insta.comment_set.all()
    context = {
        'insta': insta,
        'comment_form': comment_form,
        'comments': comments,
    }
    return render(request, 'instas/detail.html', context)


@require_POST
def delete(request, pk):
    if request.user.is_authenticated:
        insta = Insta.objects.get(pk=pk)
        if request.user == insta.user:
            insta.delete()
            return redirect('instas:index')
    return redirect('instas:index')


@require_http_methods(['GET', 'POST'])
def update(request, pk):
    insta = Insta.objects.get(pk=pk)
    if request.method == 'POST':
        form = InstaForm(request.POST, request.FILES, instance=insta)
        if form.is_valid():
            insta = form.save(commit=False)
            insta.save()
            return redirect('instas:index')

    form = InstaForm(instance=insta)
    context = {
        'form': form,
        'insta': insta,
    }
    return render(request, 'instas/update.html', context)


@require_POST
def likes(request, insta_pk):
    if request.user.is_authenticated:
        insta = Insta.objects.get(pk=insta_pk)
        if request.user in insta.like_users.all():
            insta.like_users.remove(request.user)
        else:
            insta.like_users.add(request.user)
        return redirect('instas:index')
    return redirect('account:login')


@require_POST
def comments_create(request, pk):
    if request.user.is_authenticated:
        insta = Insta.objects.get(pk=pk)
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.insta = insta
            comment.user = request.user
            comment.save()
        return redirect('instas:index')
    return redirect('accounts:login')


@require_POST
def comments_delete(request, insta_pk, comment_pk):
    if request.user.is_authenticated:
        comment = Comment.objects.get(pk=comment_pk)
        if request.user == comment.user:
            comment.delete()
    return redirect('instas:index')

<template>
  <div>
    <hr>
    <h2>결정세액: {{ finalMoney }} 만원</h2>
  </div>
</template>

<script>
export default {
  name:"FinaltaxView",
  props: {
    sanChool: Number,
    sale: Number,
  },
  computed: {
    finalMoney() {
      let final = this.sanChool - this.sale
      if (final < 0) {
        final = 0
      }
      return final
    }
  }
}
</script>

<style>

</style>
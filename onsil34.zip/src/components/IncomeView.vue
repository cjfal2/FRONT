<template>
  <div>
    <div>
      연봉 입력 (만원): <input type="number" v-model.number="plus" ><br><br>
      세액감면액 (만원): <input type="number" v-model.number="sale" >
    </div>
    <hr>
    <h2>종합소득금액 : {{ plus }} 만원</h2>
    <h2>종합소득공제 : (-) {{ gojeong }} 만원</h2>
    <h2>과세표준 : {{ calGwase }} 만원</h2>
    <TaxrateView :gwase="calGwase" :sale="sale"/>
  </div>
</template>

<script>
import TaxrateView from '@/components/TaxrateView'
export default {
  name:"IncomeView",
  components: {
    TaxrateView
  },
  data() {
    return {
      plus:0,
      gojeong:150,
      sale:0,
    }
  },
  computed: {
    calGwase() {
      let gwase = this.plus - this.gojeong
      if (gwase < 0) {
        gwase = 0
      }
      return gwase
    }
  },
  // methods: {
  //   inputPlus() {
  //     if (!this.plus.trim()) {
  //       alert("숫자를 입력하세요")
  //     }
  //   },
  //   inputSale() {
  //     if (!this.sale.trim()) {
  //       this.sale = 0
  //       alert("숫자를 입력하세요")
  //     }
  //   },
  // }
}
</script>

<style>

</style>
<template>
  <div>
    <hr>
    <h2>산출세액 : {{ sanChool }} 만원</h2>
    <h2>세액감면 : (-) {{ sale }} 만원</h2>
    <FinaltaxView :sanChool="sanChool" :sale="sale"/>

  </div>
</template>

<script>
import FinaltaxView from '@/components/FinaltaxView'
export default {
  name: "TaxrateView",
  components: {
    FinaltaxView
  },
  props: {
    gwase: Number,
    sale: Number,
  },
  computed: {
    sanChool() {
      let san = 0;
      if (this.gwase <= 1200) {
        san += Math.round(this.gwase * 0.06);
      } else if (this.gwase <= 4600) {
        san += Math.round(this.gwase * 0.15) - 108;
      } else if (this.gwase <= 8800) {
        san += Math.round(this.gwase * 0.24) - 522;
      } else if (this.gwase <= 15000) {
        san += Math.round(this.gwase * 0.35) - 1490;
      } else if (this.gwase <= 30000) {
        san += Math.round(this.gwase * 0.38) - 1940;
      } else if (this.gwase <= 50000) {
        san += Math.round(this.gwase * 0.4) - 2540;
      } else if (this.gwase <= 100000) {
        san += Math.round(this.gwase * 0.42) - 3540;
      } else {
        san += Math.round(this.gwase * 0.45) - 6540;
      }
      return san;
    },
  },
};
</script>

<style>
</style>
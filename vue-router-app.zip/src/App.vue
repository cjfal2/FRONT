<template>
  <div id="app">
    <nav>
      <!-- 선언적 방식1
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link> -->
      <!-- name routes 선언적 방식 -->
      <!-- v-bind 사용 -->
      <router-link :to="{ name: 'home'}">Home</router-link> |
      <router-link :to="{ name: 'about'}">About</router-link> |
      <router-link :to="{ name: 'hello', params: { userName: 'harry'}}">Hello</router-link> |
      <router-link :to="{ name: 'login'}">Login</router-link>
    </nav>
    <router-view/>
  </div>
</template>

<script>
export default {
  
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>

<template>
  <div>
    <h1>로그인 페이지</h1>
  </div>
</template>

<script>
export default {
  name:"LoginView",
}
</script>

<style>

</style>
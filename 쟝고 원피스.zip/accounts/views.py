from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth import update_session_auth_hash
from .forms import CustomUserChangeForm, CustomUserCreationForm


# Create your views here.
def login(request):
    if request.user.is_authenticated:
        return redirect('articles:index')

    if request.method == "POST":  #사용자를 실제 로그인 시키는 부분
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            #is_vaild 도 통과했으면
            # login(request, 유저정보) # 함수의 이름과 같아서 동작안함 import login as auth_login 으로 바꿔서 해결
            auth_login(request, form.get_user()) # login(request, user, backend=None)
            # import login -> 현재 세션에 연결하려는 인증된 사용자가 있는 경우 사용
            # result = request.GET.get("next")
            return redirect(request.GET.get("next") or 'articles:index')
    else:
        form = AuthenticationForm()
    context = {
        'form':form,
    }
    return render(request, 'accounts/login.html', context)

def logout(request):
    auth_logout(request)
    return redirect('accounts:login')

def signup(requset):
    if requset.method == "POST":
        form = CustomUserCreationForm(requset.POST)
        if form.is_valid():
            user = form.save()
            auth_login(requset, user)
            return redirect('articles:index')
    else:
        form = CustomUserCreationForm()
    context = {
        'form': form,
    }
    return render(requset, 'accounts/signup.html', context)

def delete(request):
    request.user.delete()
    return redirect('articles:index')

def update(request):
    if request.method == "POST":
        form = CustomUserChangeForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('articles:index')
    else:
        form = CustomUserChangeForm(instance=request.user)
    context = {
        'form': form,
    }
    return render(request, 'accounts/update.html', context)

def change_passsword(request):
    if request.method == "POST":
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            form.save
            update_session_auth_hash(request, form.user)
            return redirect('articles:index')
    else:
        form = PasswordChangeForm(request.user)
    context = {
        'form': form,
    }
    return render(request, 'accounts/change_passsword.html', context)


# def user_info(request):
#     user_info = Article.objects.all()
#     context = {
#         'articles': user_info,
#     }
#     return render(request, 'articles/index.html', context)

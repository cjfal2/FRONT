from tkinter import Widget
from django import forms
from .models import Choice, Comment

class ChoiceForm(forms.ModelForm):

    class Meta:
        model = Choice
        fields = '__all__'
        widgets = {
            'title': forms.TextInput(attrs={'class':'form-control'}),
            'Issue_a': forms.TextInput(attrs={'class':'form-control'}),
            'Issue_b': forms.TextInput(attrs={'class':'form-control'}),
        }


class CommentForm(forms.ModelForm):

    class Meta:
        model = Comment
        fields = ("pick", "content",)
        widgets = {
            'pick': forms.Select(attrs={'class':'form-select'}),
            'content': forms.TextInput(attrs={'class':'form-control'}),
        }

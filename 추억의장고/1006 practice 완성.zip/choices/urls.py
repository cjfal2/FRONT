from django.urls import path
from . import views

app_name = "choices"
urlpatterns = [
    path("", views.index, name="index"),
    # TODO 크리에이트
    path("create/", views.create, name="create"),
    # TODO 디테일
    path('<int:pk>/', views.detail, name='detail'),
    path('<int:pk>/comments', views.comments_create, name="comments_create"),
    # TODO 필요하면 삭제 기능

]

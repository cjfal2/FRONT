from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods, require_POST, require_safe
from .forms import ChoiceForm, CommentForm
from .models import Choice, Comment
import random

# Create your views here.
def index(request):
    choices = Choice.objects.all()
    pk_random = random.randint(1, len(choices))
    context = {
        "choices":choices,
        "pk_random":pk_random,
    }
    return render(request, "choices/index.html", context)


def create(request):
    if request.method == 'POST':
        form = ChoiceForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('choices:index')
    else:
        form = ChoiceForm()
    context = {
        'form': form,
    }
    return render(request, "choices/create.html", context)


def detail(request, pk):
    choice = Choice.objects.get(pk=pk)
    comment_form = CommentForm()
    comments = choice.comment_set.all()

    TOTAL = Comment.objects.filter(
        choice_id=pk,
    )
    RED = Comment.objects.filter(
        choice_id=pk,
        pick='RED',
    )
    BLUE = Comment.objects.filter(
        choice_id=pk,
        pick='BLUE',
    )

    TO = len(TOTAL)
    R = len(RED)
    B = len(BLUE)
    if TO:
        RP = round(R/TO*100, 1)
        BP = round(B/TO*100, 1)
    else:
        RP = 0
        BP = 0


    context = {
        'choice': choice,
        'comment_form': comment_form,
        'comments': comments,
        'RP': RP,
        'BP': BP,
    }
    return render(request, 'choices/detail.html', context)


@require_POST
def comments_create(request, pk):
    choice = Choice.objects.get(pk=pk)
    comment_form = CommentForm(request.POST)
    if comment_form.is_valid():
        comment = comment_form.save(commit=False) # 저장은 하되 커밋은 하지 않는다
        comment.choice = choice
        comment.save()
    return redirect("choices:detail", choice.pk)


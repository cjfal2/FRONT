from django import forms
from .models import Movie


class MovieForm(forms.ModelForm):
    title = forms.CharField(
        label='제목',
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'title',
                'maxlength': 20,
            }
        )
    )
    audience = forms.IntegerField(
        label='관객수',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'audience',
            }
        ),
        error_messages={
            'required': '내용을 입력하세요.',
        }
    )

    score = forms.FloatField(
        label='평점',
        widget=forms.NumberInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'score',
                'min': "0.5",
                'max': "5.0",
                'step': "0.01",
            }
        )
    )
    poster_url = forms.CharField(
        label='url',
        widget=forms.URLInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'poster_url',
            }
        )
    )
    description = forms.CharField(
        label='description',
        widget=forms.Textarea(
            attrs={
                'class': 'form-control',
                'placeholder': 'description',
            }
        )
    )



    class Meta:
        model = Movie
        fields = '__all__'
        widgets = {
            'genre': forms.Select(attrs={'class':'form-select'}),
            'release_date': forms.DateInput(attrs={'class':'form-control', 'placeholder':'Select a date', 'type':'date'}),
        }
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
# Create your models here.

genres = (
    ('코미디', '코미디'),
    ('액션', '액션'),
    ('스릴러', '스릴러'),
    ('사극', '사극'),
    ('로맨스', '로맨스'),
    ('공포', '공포'),
    ('SF', 'SF'),
)

class Movie(models.Model):
    title = models.CharField(max_length=20)
    audience = models.IntegerField()
    release_date = models.DateField()
    genre = models.CharField(max_length=20, choices=genres)
    score = models.FloatField(validators=[MinValueValidator(0.5),MaxValueValidator(5.0)])
    poster_url = models.TextField()
    description = models.TextField()


from django.contrib.auth import get_user_model, password_validation
from django.contrib.auth.forms import UserCreationForm, UserChangeForm, PasswordChangeForm, AuthenticationForm
from django import forms
from .models import Profile

class CustomUserCreationForm(UserCreationForm):
    password1 = forms.CharField(
        label= ("비밀번호"),
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password", 'class':'form-control', 'placeholder':'비밀번호를 입력하세요.'}),
        help_text=password_validation.password_validators_help_text_html(),
    )
    password2 = forms.CharField(
        label= ("비밀번호 확인"),
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password", 'class':'form-control', 'placeholder':'비밀번호 확인'}),
        # help_text= ("Enter the same password as before, for verification."),
    )

    class Meta(UserCreationForm.Meta):
        model = get_user_model()
        fields = UserCreationForm.Meta.fields + ('email',)
        labes = {
            'username':'ID',
        }
        widgets = {
            'username':forms.TextInput(attrs={'class':'form-control', 'placeholder':'아이디를 입력하세요.'}),
            'email':forms.TextInput(attrs={'class':'form-control', 'placeholder':'이메일을 입력하세요.'}),
        }


class CustomUserChangeForm(UserChangeForm):

    class Meta(UserChangeForm.Meta):
        model = get_user_model()
        fields = ('email', 'first_name', 'last_name',)
        widgets = {
            'email':forms.TextInput(attrs={'class':'form-control', 'placeholder':'이메일'}),
            'first_name':forms.TextInput(attrs={'class':'form-control', 'placeholder':'이름'}),
            'last_name':forms.TextInput(attrs={'class':'form-control', 'placeholder':'성'}),
        }

class CustomPasswordChangeForm(PasswordChangeForm):
    def __init__(self, *args, **kwargs):
        super(CustomPasswordChangeForm, self).__init__(*args, **kwargs)
        self.fields['old_password'].label = '기존 비밀번호'
        self.fields['old_password'].widget.attrs.update({
            'class': 'form-control',
            'placeholder':'기존 비밀번호',
            'autofocus': False,
        })
        self.fields['new_password1'].label = '새 비밀번호'
        self.fields['new_password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder':'새 비밀번호',
        })
        self.fields['new_password2'].label = '새 비밀번호 확인'
        self.fields['new_password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder':'새 비밀번호 확인',
        })

class LoginForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        class_update_fields = ['username', 'password']
        for field_name in class_update_fields:
            self.fields[field_name].widget.attrs.update({
                'class': 'form-control',
                'placeholder': field_name,
            })


class ProfileForm(forms.ModelForm):

    class Meta:
        model = Profile
        fields = ('nickname','introduction','image_file')
        widgets = {
            'nickname':forms.TextInput(attrs={'class':'form-control', 'placeholder':'nickname'}),
            'introduction':forms.Textarea(attrs={'class':'form-control', 'placeholder':'introduction'}),
            'image_file':forms.FileInput(attrs={'class':'form-control', 'placeholder':'image_file'}),
        }

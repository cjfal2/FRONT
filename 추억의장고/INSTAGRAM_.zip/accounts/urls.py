from django.urls import path
from . import views


app_name = 'accounts'
urlpatterns = [
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('signup/', views.signup, name='signup'),
    path('delete/', views.delete, name='delete'),
    path('update/', views.update, name='update'),
    path('password/', views.change_password, name='change_password'),
    path('delete_check/', views.delete_check, name='delete_check'),
    path('profile/<str:username>/', views.profile, name='profile'),
    path('profile/<str:username>/profile_update/', views.profile_update, name='profile_update'),
    path('<int:user_pk>/follow/', views.follow, name='follow'),
]


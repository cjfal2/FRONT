<template>
  <div @click="goDetail(article.id)">
    <hr>
    <h3>글 번호 : {{ article.id }}</h3>
    <h3>제목 : {{ article.title }}</h3>
    <hr>
  </div>
</template>

<script>
export default {
  name: "ArticleItem",
  props: {
    article:Object,
  },
  methods: {
    goDetail(id) {
      this.$router.push({ name:"detail", params:{id} })
    }
  }
}
</script>

<style>

</style>
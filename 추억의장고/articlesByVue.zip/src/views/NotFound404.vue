<template>
  <div>
    <h1>404뜸 ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ</h1>
  </div>
</template>

<script>
export default {
  name: "NotFound404",
}
</script>

<style>

</style>
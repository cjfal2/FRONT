<template>
  <div>
    <router-link :to="{ name: 'lunch' }">처음으로...</router-link>
    <h1>{{ pickedMenu }}먹고 Lotto 추첨</h1>
    <button
    @click="pickNumbers"
    >Pick Numbers</button>
    <div v-if="lottoNumbers">
      <div>{{ lottoNumbers }}</div>
      <router-link :to="{ name: 'lunch' }"><button>처음으로</button></router-link>
    </div>
  </div>
</template>

<script>
import _ from 'lodash'
export default {
  name:"LottoView",
  data() {
    return {
      pickedMenu: this.$route.params.menu,
      numbers: _.range(1, 46),
      lottoNumbers: false,
    }
  },
  methods: {
    pickNumbers() {
      this.lottoNumbers = _.sampleSize(this.numbers, 6)
      this.lottoNumbers = _.sortBy(this.lottoNumbers)
    }
  }
}
</script>

<style>

</style>
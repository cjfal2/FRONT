<template>
  <div>
    <a href="http://localhost:8080/">처음으로...</a>
    <h1>Lunch</h1>
    <button @click="pickLunch" :pickedMenu="pickedMenu">Pick Lunch</button>
    <p>{{ pickedMenu }}</p>
    <button
      v-if="pickedMenu"
      @click="goToLotto"
    >
      Lotto 뽑으러가기
    </button>
    <LottoView v-if="hide"/>
  </div>
</template>

<script>
import _ from 'lodash'
import LottoView from "@/views/LottoView"

export default {
  name:"LunchView",
  components: {
    LottoView,
  },
  data() {
    return {
      lunchMenus: ["국밥","햄버거","짜장면","라면"],
      pickedMenu: '',
      hide: '',
    }
  },
  methods: {
    pickLunch() {
      this.pickedMenu = _.sample(this.lunchMenus)
    },
    goToLotto() {
      this.$router.push({ name: 'lotto', params: { menu: this.pickedMenu } })
    }
  }
}
</script>

<style>

</style>
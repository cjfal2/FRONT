from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.views.decorators.http import require_http_methods, require_POST, require_safe
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth import update_session_auth_hash
from .forms import CustomUserChangeForm, CustomUserCreationForm
from .models import User

# Create your views here.
@require_http_methods(['GET', 'POST'])
def login(request):
    if request.user.is_authenticated:
        return redirect('articles:index')

    if request.method == "POST":  #사용자를 실제 로그인 시키는 부분
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            #is_vaild 도 통과했으면
            # login(request, 유저정보) # 함수의 이름과 같아서 동작안함 import login as auth_login 으로 바꿔서 해결
            auth_login(request, form.get_user()) # login(request, user, backend=None)
            # import login -> 현재 세션에 연결하려는 인증된 사용자가 있는 경우 사용
            # result = request.GET.get("next")
            return redirect(request.GET.get("next") or 'articles:index')
    else:
        form = AuthenticationForm()
    context = {
        'form':form,
    }
    return render(request, 'accounts/login.html', context)

@require_POST
def logout(request):
    if request.user.is_authenticated:
        auth_logout(request)
        return redirect('accounts:login')
    return redirect('articles:index')


@require_http_methods(['GET', 'POST'])
def signup(request):
    if request.user.is_authenticated:
        return redirect('articles:index')

    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            return redirect('articles:index')
    else:
        form = CustomUserCreationForm()
    context = {
        'form': form,
    }
    return render(request, 'accounts/signup.html', context)


@require_POST
def delete(request):
    if request.user.is_authenticated:
        request.user.delete()
        return redirect('articles:index')
    return redirect('articles:index')


@require_http_methods(['GET', 'POST'])
def update(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            form = CustomUserChangeForm(request.POST, instance=request.user)
            if form.is_valid():
                form.save()
                return redirect('articles:index')
        else:
            form = CustomUserChangeForm(instance=request.user)
        context = {
            'form': form,
        }
        return render(request, 'accounts/update.html', context)
    return redirect('articles:index')


@require_http_methods(['GET', 'POST'])
def change_passsword(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            form = PasswordChangeForm(request.user, request.POST)
            if form.is_valid():
                form.save
                update_session_auth_hash(request, form.user)
                return redirect('articles:index')
        else:
            form = PasswordChangeForm(request.user)
        context = {
            'form': form,
        }
        return render(request, 'accounts/change_passsword.html', context)
    return redirect('articles:index')


@require_safe
def index(request):
    index = User.objects.all()
    # print(request.get_host())
    context = {
        'accounts': index,
    }
    return render(request, 'accounts/index.html', context)

def profile(request):
    profile = User.objects.all()
    context = {
        'accounts': profile,
    }
    return render(request, "accounts/profile.html", context)
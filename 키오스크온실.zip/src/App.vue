<template>
  <div id="app">
    <h1 class="fw-bold">Coffee Order App</h1>
    <div class="container">
      <div class="container d-flex rounded-4 p-2" style="background-color:rgb(240, 240, 240); height: 25rem;">
        <div class="container m-2 rounded-4" style="background-color:white;">
          <h3 @click="toggleMenu" class="my-3 fw-bold fst-italic">Coffee</h3>
          <MenuList
            v-if="flagMenu"
          />
        </div>
        <div class="container m-2 rounded-4" style="background-color:white;">
          <h3 @click="toggleSize" class="my-3 fw-bold fst-italic">Size</h3>
          <SizeList
            v-if="flagSize"
          />
        </div>
        <div class="container m-2 rounded-4" style="background-color:white;">
          <h3 @click="toggleOption" class="my-3 fw-bold fst-italic">Option</h3>
          <OptionList
            v-if="flagOption"
          />
        </div>
      </div>
      <div class="m-3 d-grid gap-2">
        <button 
          class="btn btn-lg"
          style="background-color: rgb(82, 177, 123); color:white;"
          @click="addMenu"
        >
          <b>장바구니 담기</b>
        </button>
      </div>
      <div class="container rounded-3" style="background-color: rgb(240, 240, 240);">
        <OrderList
        
        />
      </div>
    </div>
  </div>
</template>

<script>
import OrderList from '@/components/OrderList';
import SizeList from '@/components/SizeList';
import MenuList from '@/components/MenuList';
import OptionList from '@/components/OptionList';

export default {
  name: 'App',
  components: {
    OrderList,
    SizeList,
    MenuList,
    OptionList,
  },
  data() {
    return {
      flagMenu: false,
      flagSize: false,
      flagOption: false,
    }
  },
  methods: {
    toggleMenu() {
      this.flagMenu = !this.flagMenu
    },
    toggleSize() {
      this.flagSize = !this.flagSize
    },
    toggleOption() {
      this.flagOption = !this.flagOption
    },
    addMenu() {
      this.$store.commit("ADD_ORDER")
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

<template>
  <div>
    <div
      style="height:5rem;"
      class="m-3 p-2 d-flex justify-content-between border border-2 border-dark rounded-3 align-items-center"
      @click="updateMenuStatus"
      :class="{ 'is-selected':menu.selected }"
    >
      <div>
        <img :src="menu.image" alt="x" style="width:50px; height:50px" class="rounded-3">
      </div>
      <div class="fw-bold fst-italic">
        {{ menu.title }}
      </div>
      <div class="fw-bold fst-italic">
        {{ menu.price }} 원
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "MenuItemList",
  props: {
    menu: Object,
  },
  methods: {
    updateMenuStatus() {
      this.$store.dispatch('updateMenuStatus', this.menu)
    }
  }
}
</script>

<style>
  .is-selected {
    background-color: rgb(82, 177, 123);
    color: white;
  }
</style>
<template>
  <div>
    <MenuItemList
      v-for="(menu, index) in menuList" :key="index"
      :menu="menu"
    />
  </div>
</template>

<script>
import MenuItemList from '@/components/MenuItemList';
export default {
  name:"MenuList",
  components: {
    MenuItemList,
  },
  computed: {
    menuList() {
      return this.$store.state.menuList
    }
  }
}
</script>

<style>

</style>
<template>
  <div>
    <OptionListItem
      v-for="(option, index) in optionList" :key="index"
      :option="option"
    />
  </div>
</template>

<script>
import OptionListItem from '@/components/OptionListItem';
export default {
  name:"OptionList",
  components: {
    OptionListItem,
  },
  computed: {
    optionList() {
      return this.$store.state.optionList
    }
  }
}
</script>

<style>

</style>
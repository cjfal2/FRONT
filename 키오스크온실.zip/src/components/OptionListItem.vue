<template>
  <div>
    <div
      style="height:5rem;"
      class="m-3 p-2 d-flex justify-content-between border border-2 border-dark rounded-3 align-items-center"
    >
      <div class="m-2 fw-bold">
        {{ option.type }}
      </div>
      <div>
        <button
          class="rounded-circle"
          style="width:30px;"
          @click="updateOptionStatusMinus"
        >-</button>
        <span class="m-1 fw-bold fst-italic">
          {{ option.count }}
        </span>
        <button
          class="rounded-circle"
          style="width:30px;"
          @click="updateOptionStatusPlus"
        >+</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name:"OptionListItem",
  data() {
    return {
      optionCount: this.option.count
    }
  },
  props: {
    option: Object,
  },
  methods: {
    updateOptionStatusPlus() {
      this.$store.dispatch('updateOptionStatusPlus', this.option)
    },
    updateOptionStatusMinus() {
      this.$store.dispatch('updateOptionStatusMinus', this.option)
    },
  }

}
</script>

<style>

</style>
<template>
  <div class="py-4 px-2">
    <h3 class="text-start fw-bold">주문내역</h3>
    <div class="text-start my-4 fw-bold">총 {{ allOrdersCount }}건: {{ totalPay }}원 </div>
    <div
      v-for="(order, index) in orderList" :key="index"
    >
    <div class="container d-flex justify-content-between">
      <div class="d-flex m-1">
        <img :src="order.menu.image" alt="x" style="width:50px; height: 50px;" class="rounded-3">
        <div class="container row">
          <span class="text-start col-12 fw-bold">
            {{ order["menu"]["title"] }}
          </span>
          <span class="text-start col-12 ">
            <b>Size: </b>{{ order["size"]["name"] }}
          </span>
        </div>
      </div>
      <div class="d-flex m-1">
        <div class="container row">
          <span class="text-end col-12 fw-bold">
            가격: {{ order["menu"]["price"]+order["size"]["price"]+(order["바닐라 시럽"]["count"]*300)+(order["바닐라 시럽"]["count"]*400)+(order["캬라멜 시럽"]["count"]*500) }}원
          </span>
          <span class="text-end col-12">
            샷: {{ order["샷"]["count"] }} 회 |
            바닐라 시럽: {{ order["바닐라 시럽"]["count"] }} 회 |
            캬라멜 시럽: {{ order["캬라멜 시럽"]["count"] }} 회 |
          </span>
        </div>
      </div>
    </div>
    <hr>
    </div>
  </div>
</template>

<script>
export default {
  name: "OrderList",
  computed: {
    orderList() {
      return this.$store.state.orderList
    },
    allOrdersCount() {
      return this.$store.getters.allOrdersCount
    },
    totalPay() {
      return this.$store.getters.totalPay

    }
  }
}
</script>

<style>

</style>
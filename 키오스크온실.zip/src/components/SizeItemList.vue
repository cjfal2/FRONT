<template>
  <div>
    <div
      style="height:5rem;"
      class="m-3 p-2 d-flex justify-content-between border border-2 border-dark rounded-3 align-items-center"
      @click="updateSizeStatus"
      :class="{ 'is-selected':size.selected }"
    >
      <div class="m-2 fw-bold">
        {{ size.name }}
      </div>
      <div class="m-2 fw-bold fst-italic">
       + {{ size.price }} 원
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name:"SizeItemList",
  props: {
    size: Object,
  },
  methods: {
    updateSizeStatus() {
      this.$store.dispatch('updateSizeStatus', this.size)
    }
  }
}
</script>

<style>
  .is-selected {
    background-color: rgb(82, 177, 123);
    color: white;
  }
</style>
<template>
  <div>
    <SizeItemList
      v-for="(size, index) in sizeList" :key="index"
      :size="size"
    />
  </div>
</template>

<script>
import SizeItemList from '@/components/SizeItemList';
export default {
  name:"SizeList",
  components: {
    SizeItemList,
  },
  computed: {
    sizeList() {
      return this.$store.state.sizeList
    }
  }
}
</script>

<style>

</style>
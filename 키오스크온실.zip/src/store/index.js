import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    orderList: [],
    menuList: [
      {
        title: '아메리카노',
        price: 3000,
        selected: true,
        image: "https://image.istarbucks.co.kr/upload/store/skuimg/2021/04/[94]_20210430103337157.jpg"
      },
      {
        title: '카페라떼',
        price: 4000,
        selected: false,
        image: "https://image.istarbucks.co.kr/upload/store/skuimg/2015/08/[41]_20150813221501796.jpg"
      },
      {
        title: '카푸치노',
        price: 5000,
        selected: false,
        image: "https://image.istarbucks.co.kr/upload/store/skuimg/2021/04/[38]_20210415154821991.jpg"
      },
    ],
    sizeList: [
      {
        name: "small",
        price: 0,
        selected: true
      },
      {
        name: "medium",
        price: 500,
        selected: false
      },
      {
        name: "large",
        price: 1000,
        selected: false
      },
    ],
    optionList: [
      {
        type: '샷',
        price: 300,
        count: 0,
      },
      {
        type: '바닐라 시럽',
        price: 400,
        count: 0,
      },
      {
        type: '캬라멜 시럽',
        price: 500,
        count: 0,
      },
    ]
  },
  getters: {
    allOrdersCount(state) {
      return state.orderList.length
    },
    totalPay(state) {
      let total = 0
      state.orderList.forEach((selprice) => {
        total = total + selprice.menu.price + selprice.size.price + selprice.totalOption
      })
      return total
    }
  },
  mutations: {
    UPDATE_MENULIST(state, selectedMenu) {
      state.menuList = state.menuList.map((menu) => {
        menu.selected = false
        return menu
      })
      state.menuList = state.menuList.map((menu) => {
        if (menu === selectedMenu) {
          menu.selected = true
        }
        return menu
      })
    },
    UPDATE_SIZELIST(state, selectedSize) {
      state.sizeList = state.sizeList.map((size) => {
        size.selected = false
        return size
      })
      state.sizeList = state.sizeList.map((size) => {
        if (size === selectedSize) {
          size.selected = true
        }
        return size
      })
    },
    ADD_ORDER(state) {
      const order = {}
      state.menuList.forEach((menu) => {
        if (menu.selected === true) {
          order["menu"] = {"title":menu.title, "price":menu.price, "image":menu.image}
        }
      })
      state.sizeList.forEach((size) => {
        if (size.selected === true) {
          order["size"] = {"name":size.name, "price":size.price}
        }
      })
      let totalOption = 0
      state.optionList.forEach((option) => {
        order[option.type] = {"count":option.count}
        totalOption += option.count * option.price
      })
      order["totalOption"] = totalOption 
      console.log(order)
      state.orderList.push(order)
      // TODO: 옵션리스트들 숫자 되돌리기
    },
    UPDATE_OPTION_LIST_PLUS(state, optionItem) {
      state.optionList.forEach((element) => {
        if (element.type === optionItem.type) {
          element.count ++
        }
      })
    },
    UPDATE_OPTION_LIST_MINUS(state, optionItem) {
      state.optionList.forEach((element) => {
        if (element.type === optionItem.type) {
          element.count --
        }
      })
    },
  },
  actions: {
    updateMenuStatus(context, menuItem) {
      context.commit("UPDATE_MENULIST", menuItem)
    },
    updateSizeStatus(context, sizeItem) {
      context.commit("UPDATE_SIZELIST", sizeItem)
    },
    updateOptionStatusPlus(context, optionitem) {
      context.commit("UPDATE_OPTION_LIST_PLUS", optionitem)
    },
    updateOptionStatusMinus(context, optionitem) {
      context.commit("UPDATE_OPTION_LIST_MINUS", optionitem)
    },
  },
  modules: {
  }
})
